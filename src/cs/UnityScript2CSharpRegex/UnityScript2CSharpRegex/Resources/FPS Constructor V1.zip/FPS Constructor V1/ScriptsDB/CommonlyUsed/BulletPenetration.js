var penetrateValue : int = 1;
