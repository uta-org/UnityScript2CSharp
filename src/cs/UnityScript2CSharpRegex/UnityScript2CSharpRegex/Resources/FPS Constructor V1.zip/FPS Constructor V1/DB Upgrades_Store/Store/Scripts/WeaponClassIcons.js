//Array to hold icons for the Weapon Classes
//A Custom Editor Script only displays the number of actual Weapon Classes Defined in WeaponInfo
var weaponClassTextures : Texture[] = new Texture[20];