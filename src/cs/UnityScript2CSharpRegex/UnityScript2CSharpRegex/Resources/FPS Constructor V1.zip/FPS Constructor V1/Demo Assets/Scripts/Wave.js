#pragma strict
var cubeSets : CubeSet[];